# 空工作区

由GPT运行bootstrap生成这本书的新身份。不要复制旧书state.json。
